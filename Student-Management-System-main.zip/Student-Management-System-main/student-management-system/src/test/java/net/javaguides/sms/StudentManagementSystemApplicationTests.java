package net.javaguides.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
